package datamodel;

public class DateManipulation {
}
